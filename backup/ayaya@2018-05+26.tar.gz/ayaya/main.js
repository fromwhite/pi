const Koa = require('koa');
const views = require('koa-views');
const json = require('koa-json');
const bodyParser = require('koa-bodyparser');
const session = require('koa-session');

const face = require('./interface');

const Router = require('koa-router');
const router = Router();
router.get('/', face.index)
    .get('/lab', face.lab)
    .get('/login', face.login)
    .post('/login', face.loginEvt)
    .get('/post/:name', face.post)
    .get('*', async (ctx, next) => {
        ctx.status = 404
        ctx.body = '404'
        //await ctx.render('404');
    });

const app = new Koa();
app.keys = ['Ayaya'];

async function logger(ctx, next) {
    // console.log('request url:', ctx.url);
    const start = new Date();
    await next()
    console.log(`method: ${ctx.method} code: ${ctx.status} time:${new Date - start}ms`);
    // console.log(ctx.ms, 12)
}

// app.use(logger);
app.use(face.file);

// 单核套路云 直接写内存
let store = {
    storage: {},
    get(key, maxAge) {
        return this.storage[key]
    },
    set(key, sess, maxAge) {
        this.storage[key] = sess
    },
    destroy(key) {
        delete this.storage[key]
    }
}

app.use(session({
    key: 'Aayaya .*?%',
    maxAge: 3600000 * 24 * 30,
    overwrite: true,
    httpOnly: true,
    rolling: false,
    sign: true,
    store: store
}, app))

app.use(bodyParser({
    enableTypes: ['json', 'form', 'text']
}));
app.use(json());
app.use(require('koa-static')(__dirname + '/assets/'));
app.use(views(__dirname + '/views', {
    extension: 'ejs'
}));

app.use(router.routes(), router.allowedMethods());

app.listen(80, () => {
    console.log(`Starting..`)
});

module.exports = app;